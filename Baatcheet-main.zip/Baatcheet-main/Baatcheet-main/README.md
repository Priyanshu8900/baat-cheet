# Baatcheet
It is an web application in which people can share their view and express their opinion
